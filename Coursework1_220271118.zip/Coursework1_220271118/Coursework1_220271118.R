# title: MTH6139 Time Series Coursework 1
# author: Syed Miah
# date: 17/03/2025

library(prophet) # Loads the Prophet Library Ready for Use
library(zoo) # Loads the Zoo Library Ready for Use

RetailSalesDataExample <- read.csv("data/RetailSalesDataExample.csv") # Read the .csv Data File

RetailSales.DataFrame <- data.frame(
    ds = zoo::as.Date(RetailSalesDataExample$ds), #Ensures that the ds Column is a Date
    y = RetailSalesDataExample$y)
options(scipen = 999) # Forces the Plot to not use scientific notation
plot(RetailSales.DataFrame$ds, RetailSales.DataFrame$y, type="l", xlab = "Time", ylab = "Sales", main = "Retail Sales Over Time") # Plotting the Time Series, with Labels and a Title

HistoricRetailSales <- prophet(RetailSales.DataFrame) # Training the Model with Historic Data
FutureRetailSales <- make_future_dataframe(HistoricRetailSales, periods = 730) # Creating a Future Dataframe with a Period of 2 years
ForecastedRetailSales <- predict(HistoricRetailSales, FutureRetailSales) # Producing a prediction / forecasted retail sales
plot(HistoricRetailSales, ForecastedRetailSales) # A plot of the Forecasted Sales and Historic Sales to Compare

prophet_plot_components(HistoricRetailSales, ForecastedRetailSales) # Plotting additional Trends and Seasonality Graphs for Analysis
